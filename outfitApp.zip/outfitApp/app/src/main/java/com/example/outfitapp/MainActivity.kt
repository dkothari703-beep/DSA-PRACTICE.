package com.example.outfitapp
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

            val topColor = findViewById<EditText>(R.id.topColor)
            val suggestBtn = findViewById<Button>(R.id.suggestBtn)
            val result = findViewById<TextView>(R.id.result)

            suggestBtn.setOnClickListener {
                val color = topColor.text.toString().lowercase()

                when (color.lowercase()) {
                    "red" -> result.text = getString(R.string.wear_black_or_white_jeans)
                    "white" -> result.text = getString(R.string.wear_any_jeans)
                    "black" -> result.text = getString(R.string.wear_grey_or_beige_jeans)
                    else -> result.text = getString(R.string.try_black_jeans)
                }

        }
    }
}